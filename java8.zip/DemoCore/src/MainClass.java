import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class MainClass {

	public static void main(String[] args) {

		/*
		 * int num1[]= {1,3,5}; int num2[]= {2,4};
		 * 
		 * int totalLen = num1.length+num2.length;
		 * 
		 * List<int[]> l1 = Arrays.asList(num1); List<int[]> l2 = Arrays.asList(num2);
		 * 
		 * l1.addAll(l2); System.out.println(l1.toString());
		 */

		// countDuplicateCharacterUsingMap();
		// reverseStringUsingBasic();
		// reverseUsingMethod();
		//reverseUsingCollection();
		 usingSplit();
	}

	public static void countDuplicateCharacterUsingMap() {
		String place = "shravan";

		Map<Character, Integer> map = new HashMap<Character, Integer>();

		char[] charArray = place.toCharArray();

		for (char c : charArray) {

			if (map.containsKey(c)) {

				map.put(c, map.get(c) + 1);
			} else {
				map.put(c, 1);
			}
		}

		System.out.println(map);
	}

	public static void reverseStringUsingBasic() {
		String p1 = "shravan";
		char[] len = p1.toCharArray();
		for (int i = len.length - 1; i >= 0; i--)
			System.out.print(" " + len[i]);
	}

	public static void reverseUsingMethod() {
		String p1 = "shravan";
		StringBuffer sb = new StringBuffer();
		sb.append(p1);
		sb.reverse();
		System.out.println(sb);
	}

	public static void reverseUsingCollection() {
		String p1 = "shravan";
		char[] charArray = p1.toCharArray();
		ArrayList<Character> clist = new ArrayList<>();
		for (int i = 0; i < charArray.length; i++) {
			clist.add(charArray[i]);
		}

		Collections.reverse(clist);
		System.out.println("ArrayList:" + clist);
	}

	public static void usingSplit() {
		String s = "test test new test";

		String[] split = s.split(" ");
		String filter1 = null;
		for (int i = 0; i < split.length; i++) {
			for (int j = i + 1; j < split.length - 1; j++) {
				if (split[i] == split[j]) {
					filter1 ="";
				}
			}
		}

		System.out.println(filter1);
	}
}
