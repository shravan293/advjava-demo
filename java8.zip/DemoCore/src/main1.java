import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class main1 {

	public static void main(String[] args) {
		
		  
		
		  int num1[]= {1,3,5}; int num2[]= {2,4};
		  
		  int totalLen = num1.length+num2.length;
		  
		  List<int[]> l1 = new ArrayList(Arrays.asList(num1)); 
		  List<int[]> l2 = new ArrayList(Arrays.asList(num2));
		  
		  
		  l1.addAll(l2); 
		  System.out.println(l1.toString());
		 
			/*
			 * List<String> newList = new ArrayList<>(listOne.size() + listTwo.size());
			 * newList.addAll(listOne); newList.addAll(listTwo);
			 */
		  
		  System.out.println("hello java");
		 
	}

}
