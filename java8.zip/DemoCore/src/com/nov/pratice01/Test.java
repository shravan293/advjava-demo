package com.nov.pratice01;

public class Test {

	public static void main(String[] args) {
		
		/*
		 * StringBuffer s1=new StringBuffer("Yash"); //String s2=s1.reverse();
		 * StringBuffer s2=s1.reverse(); System.out.println(s2);
		 */
		
		/*
		 * String s1="yash"; String s=new String("Jaynam");
		 * System.out.println(s1+"= "+s);
		 */
		
		
		/*
		 * int[][] a= {{10,20,40},{50,60},{90,80,70}}; System.out.println(a.length);
		 * System.out.println(a); System.out.println(a[0]); System.out.println(a[0][0]);
		 */
		
		//int[] a=new int[-5];
		
		/*
		 * int[][] a,b; System.out.println(a+"="+b);
		 */
		
		
	}
	
	
}
