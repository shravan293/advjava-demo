
public class Pratice1 {

	public static void main(String[] args) {
		
		
		/*
		 * String s1="shravan"; String s2="kumbhar";
		 * 
		 * StringBuilder sb1=new StringBuilder(s1); sb1.insert(3, s2.toCharArray());
		 * System.out.println(sb1.toString());
		 */
		
		
		int[] arr= {10,5,3,2,1,19};
		
	}

}
