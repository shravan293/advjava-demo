package database;

import java.sql.*;
class FirstJdbcDemo
{
	public static void main(String[] args)
	{
		try
		{
			//1.load the driver
			Class.forName("com.mysql.jdbc.Driver");
			//2.create connection
			String url="jdbc:mysql://localhost:3306/jaynam";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url,user,pass);
			if(con!=null)
			{
				System.out.println("Connection is created Successfully");
				
			}
			else
			{
				System.out.println("Connection is not created");
			}//step 3 :create query
			String q="select * from employee";
			Statement st=con.createStatement();
			ResultSet set=st.executeQuery(q);
			//step4 process the data
			while(set.next())
			{
				int id=set.getInt("empID");//(1)
				String name=set.getString("name");//(2)
				System.out.println("id:" + id);
				System.out.println("name" +name);
			}
				//step 5: connection close
				con.close();
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}

		