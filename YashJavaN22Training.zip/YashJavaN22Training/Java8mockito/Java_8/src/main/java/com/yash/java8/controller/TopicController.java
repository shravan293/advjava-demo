package com.yash.java8.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.yash.java8.model.Topic;
import com.yash.java8.service.TopicService;

@RestController
public class TopicController {

	@Autowired
	private TopicService topicService;

	/**
	 * Get all Topic
	 * 
	 * @return
	 */
	@RequestMapping("/topic")
	public List<Topic> getAllTopics() {
		return topicService.getAllTopics();
	}

	/**
	 * get Topic with ID
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping("/topic/{id}")
	public Topic getTopicWithID(@PathVariable String id) {
		return topicService.getTopicWithId(id);
	}

	/**
	 * Add a new topic in list
	 * 
	 * @param topic
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/topic")
	public void addTopic(@RequestBody Topic topic) {
		topicService.addTopic(topic);

	}

	/**
	 * Delete a topic with ID
	 * 
	 * @param id
	 */
	@RequestMapping(method = RequestMethod.DELETE, value = "/topic/{id}")
	public void deleteTopic(@PathVariable String id) {
		topicService.deleteTopic(id);
	}

}
