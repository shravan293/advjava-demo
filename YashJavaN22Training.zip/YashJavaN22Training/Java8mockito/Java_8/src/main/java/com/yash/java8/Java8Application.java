package com.yash.java8;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Project regarding Java8 feature in spring boot
 * @author sajan.kumar
 *
 */

@SpringBootApplication
public class Java8Application {

	public static void main(String[] args) {
		SpringApplication.run(Java8Application.class, args);
	}

}
