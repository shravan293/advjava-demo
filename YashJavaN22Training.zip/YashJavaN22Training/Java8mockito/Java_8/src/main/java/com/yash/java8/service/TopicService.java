package com.yash.java8.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.yash.java8.model.Topic;

@Service
public class TopicService {

	private List<Topic> topics = new ArrayList<>(
			Arrays.asList(new Topic("spring", "Spring Framework", "Spring Framework Description"),
					new Topic("java", "Core Java", "Java Description"),
					new Topic("javascript", "javascript Framework", "javascript Framework Description")));


	public List<Topic> getTopics() {
		return topics;
	}

	public void setTopics(List<Topic> topics) {
		this.topics = topics;
	}

	public List<Topic> getAllTopics() {
		return topics;
	}

	/**
	 * Stream Example
	 *
	 * @param id
	 * @return
	 */
	public Topic getTopicWithId(String id) {
		return topics.stream().filter(topic -> topic.getId().equals(id)).findFirst().get();
	}

	public void addTopic(Topic topic) {
		topics.add(topic);

	}

	/**
	 * Lambda Expressions
	 *
	 * @param id
	 */
	public void deleteTopic(String id) {
		topics.removeIf(topic -> topic.getId().equals(id));
	}

}
