package com.yash.thrty;

public class Game {
	
	private Player player;

	public Game(Player player) {
		this.player = player;
	}

	public String display()
	{
         return "display"+player.getPlayername();
	}
}