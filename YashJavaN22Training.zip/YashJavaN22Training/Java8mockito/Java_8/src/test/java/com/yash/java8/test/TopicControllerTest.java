package com.yash.java8.test;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.event.annotation.AfterTestClass;
import org.springframework.test.context.event.annotation.BeforeTestClass;
import org.springframework.test.web.servlet.MockMvc;

import com.yash.java8.model.Topic;
import com.yash.java8.service.TopicService;

@RunWith(MockitoJUnitRunner.class)
class TopicControllerTest {

	@MockBean
	TopicService topicService;

	@Mock
	MockMvc mockMvc;
	
	@BeforeEach
	public void setup() {
	    MockitoAnnotations.initMocks(this);
	}

	@BeforeTestClass
	public static void intiBeforeClass() throws Exception {
		System.out.println("intiBeforeClass()");
	}

	@AfterTestClass
	public static void cleanAfterClass() throws Exception {
		System.out.println("cleanAfterClass()");
	}

	@Test
	public void getAllTopics() throws Exception {
		Topic topic = new Topic("java", "Core Java", "Java Description");
	/*	List<Topic> topics = Arrays.asList(topic);

		Mockito.when(topicService.getAllTopics()).thenReturn(topics);
		mockMvc.perform(get("/topic")).andExpect(status().isOk()).andExpect(jsonPath("$", Matchers.hasSize(1)))
			*/	//.andExpect(jsonPath("$[0].id", Matchers.is("java")));
		//
		//assertEquals(topic, topicService.getAllTopics());
		System.out.println(topic+""+topicService.getAllTopics());
	}

	@Test
	public void test() {
		Topic topic = new Topic("java", "Core Java", "Java Description");
		
		System.out.println("Tested");
		System.out.println(topic+""+topicService.getAllTopics());
	}

}
