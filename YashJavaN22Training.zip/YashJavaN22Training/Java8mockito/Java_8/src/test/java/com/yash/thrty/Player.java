package com.yash.thrty;

public class Player {

	private String playername;

	public Player(String playername)
	{
		this.playername = playername;
	}

	String getPlayername()
	{
		return playername;
	}
}
