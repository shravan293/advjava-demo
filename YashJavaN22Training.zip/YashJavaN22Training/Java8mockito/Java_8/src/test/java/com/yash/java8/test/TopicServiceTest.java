package com.yash.java8.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.event.annotation.AfterTestClass;
import org.springframework.test.context.event.annotation.BeforeTestClass;
import org.springframework.test.web.servlet.MockMvc;

import com.yash.java8.model.Topic;
import com.yash.java8.service.TopicService;

@RunWith(MockitoJUnitRunner.class)
public class TopicServiceTest {

	@InjectMocks
	TopicService topicService;

	@Autowired
	MockMvc mockMvc;
	
	@BeforeEach
	public void setup() {
	    MockitoAnnotations.initMocks(this);
	}

	@BeforeTestClass
	public static void intiBeforeClass() throws Exception {
		System.out.println("intiBeforeClass()");
	}

	@AfterTestClass
	public static void cleanAfterClass() throws Exception {
		System.out.println("cleanAfterClass()");
	}

	@Test
	public void getAllTopics() throws Exception {
		Topic topic = new Topic("java", "Core Java", "Java Description");
	/*	List<Topic> topics = Arrays.asList(topic);

		Mockito.when(topicService.getAllTopics()).thenReturn(topics);
		mockMvc.perform(get("/topic")).andExpect(status().isOk()).andExpect(jsonPath("$", Matchers.hasSize(1)))
			*/	//.andExpect(jsonPath("$[0].id", Matchers.is("java")));
		//
		assertEquals(topic.toString(), topicService.getAllTopics().toString());
		
	}
	
	
	@Test
	public void getTopicWithIdTest() {
		
		assertEquals(new Topic("spring", "Spring Framework", "Spring Framework Description").toString(), topicService.getTopicWithId("spring").toString());
		
	}

	@Test
	public void test() {
		Topic topic = new Topic("java", "Core Java", "Java Description");
		
		System.out.println("Tested");
		System.out.println(topic+""+topicService.getAllTopics());
	}

}
