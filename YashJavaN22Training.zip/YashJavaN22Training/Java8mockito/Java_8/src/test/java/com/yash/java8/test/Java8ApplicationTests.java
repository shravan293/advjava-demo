package com.yash.java8.test;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.yash.java8.controller.TopicController;

@SpringBootTest
class Java8ApplicationTests {
	
	@Autowired
	TopicController topicController;

	@Test
	void contextLoads() {
		
		Assertions.assertThat(topicController).isNotNull();
	}

}
