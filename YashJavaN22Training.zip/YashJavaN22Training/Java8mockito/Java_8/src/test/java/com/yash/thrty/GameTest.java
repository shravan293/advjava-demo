package com.yash.thrty;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

public class GameTest {

	@Mock
	Player player;

	@InjectMocks
	Game game;

	@Test
	public void test1() throws Exception {
		Mockito.when(player.getPlayername()).thenReturn("Jaynam");
		assertEquals("display Jaynam", game.display());
	}
}
